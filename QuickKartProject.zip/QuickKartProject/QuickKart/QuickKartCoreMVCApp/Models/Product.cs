﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QuickKartCoreMVCApp.Models
{
    public class Product
    {
        [DisplayName("Category Id")]
        [Required(ErrorMessage = "Category Id is mendatory")]
        public byte? CategoryId { get; set; }

        [DisplayName("Price")]
        [Required(ErrorMessage = "Price is mendatory")]
        public decimal Price { get; set; }

        [DisplayName("Product Id")]
        [Required(ErrorMessage = "Product Id is mendatory")]
        public string ProductId { get; set; }

        [DisplayName("Product Name")]
        [Required(ErrorMessage = "Product Name is mendatory")]
        [MinLength(3,ErrorMessage = "Product Name length is minimum 3")]
        public string ProductName { get; set; }

        [DisplayName("Quantity Available")]
        [Required(ErrorMessage = "Quantity Available is mendatory")]
        [Range(0,int.MaxValue,ErrorMessage ="Quantity Avalable is greater than zero")]
        public int QuantityAvailable { get; set; }

    }
}
