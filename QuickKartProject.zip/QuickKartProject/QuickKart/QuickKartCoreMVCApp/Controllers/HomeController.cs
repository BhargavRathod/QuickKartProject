﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QuickKartCoreMVCApp.Models;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

namespace QuickKartCoreMVCApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly QuickKartContext _context;
        QuickKartRepository repObj;
        public HomeController(QuickKartContext context)
        {
            _context = context;
            repObj = new QuickKartRepository(_context);
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult CheckRole(IFormCollection frm)
        {
            string userId = frm["name"];
            string password = frm["pwd"];
            string checkbox = frm["RememberMe"];
            if (checkbox == "on")
            {
                CookieOptions cookie = new CookieOptions();
                cookie.Expires = DateTime.Now.AddDays(1);
                Response.Cookies.Append("UserId", userId, cookie);
                Response.Cookies.Append("Password", password, cookie);
            }

            string username = userId.Split('@')[0];

            byte? roleId = repObj.ValidateCredentials(userId, password);
            if (roleId == 1)
            {
                HttpContext.Session.SetString("username",username);
                return RedirectToAction("AdminHome", "Admin");
            }
            else if (roleId == 2)
            {
                HttpContext.Session.SetString("Customer_userId", userId);
                return Redirect("/Customer/CustomerHome?username=" + username);
            }
            return View("Login");
        }

        public JsonResult GetCoupons()
        {
            Random random = new Random();
            Dictionary<string, string> data = new Dictionary<string, string>();
            string[] value = new String[5];
            string[] key = { "Arts", "Electronics", "Fashion", "Home", "Toys" };
            for (int i = 0; i < 5; i++)
            {
                string number = "RUSH" + random.Next(1, 10).ToString() + random.Next(1, 10).ToString() + random.Next(1, 10).ToString();
                value[i] = number;
            }
            for (int i = 0; i < 5; i++)
            {
                data.Add(key[i], value[i]);
            }
            return Json(data);
        }

        public ContentResult XMLDemo()
        {
            string xml = "<xml><Coupons><coupon><cid>1</cid><cname>MyFirstCoupon</cname><cvalue>100153</cvalue></coupon></Coupons></xml>";
            return Content(xml, "text/xml");
        }

        public ViewResult FAQ()
        {
            return View();
        }
        

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public ViewResult Contact()
        {
            //ViewData["Message"] = "Your contact page.";

            return View();
        }

       

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
       
    }
}
