﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartCoreMVCApp.Controllers
{
    public class CategoryController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        private readonly IMapper _mapper;
        private readonly QuickKartContext _context;
        QuickKartRepository repObj;

        public CategoryController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }

        
        public IActionResult AddCategory(Models.Category obj)
        {
            if (ModelState.IsValid)
            {
                bool ret = repObj.AddCategory(_mapper.Map<Categories>(obj));
                if (ret)
                {
                    return RedirectToAction("ViewCategory");
                }
                else
                {
                    return View("Error");
                }

            }
            return View("AddCategory", obj);
        }

        public IActionResult ViewCategory()
        {
            var lstCategories = repObj.GetCategories();
            List<Models.Category> lstModelCategories = new List<Models.Category>();
            foreach (var category in lstCategories)
            {
                lstModelCategories.Add(_mapper.Map<Models.Category>(category));
            }
            return View(lstModelCategories);
        }

        public IActionResult UpdateCategory(Models.Category catObj)
        {
            return View(catObj);
        }
        [HttpPost]
        public IActionResult SaveUpdatedCategory(Models.Category cat)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                try
                {
                    status = repObj.UpdateCategory(_mapper.Map<Categories>(cat));
                    if (status)
                        return RedirectToAction("ViewCategory");
                    else
                        return View("Error");
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("UpdateProduct", cat);
        }

        public IActionResult DeleteCategory(Models.Category cat)
        {
            return View(cat);
        }

        public IActionResult SaveCategoryDeletion(Models.Category cat)
        {
            bool status = false;
            try
            {
                status = repObj.DeleteCategory(_mapper.Map<Categories>(cat));
                if (status)
                    return RedirectToAction("ViewCategory");
                else
                    return View("Error");
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
    }
}
