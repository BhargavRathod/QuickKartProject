﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using QuickKartDataAccessLayer;
using QuickKartDataAccessLayer.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace QuickKartCoreMVCApp.Controllers
{
    public class PurchaseController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        private readonly QuickKartContext _context;
        private readonly IMapper _mapper;
        QuickKartRepository repObj;

        public PurchaseController(QuickKartContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
            repObj = new QuickKartRepository(_context);
        }

        public IActionResult PurchaseProduct(Models.Product productObj)
        {
            Models.PurchaseDetails purchaseObj = new Models.PurchaseDetails();
            purchaseObj.EmailId = HttpContext.Session.GetString("Customer_userId").ToString();
            purchaseObj.ProductId = productObj.ProductId;
            purchaseObj.DateOfPurchase = DateTime.Now;
            TempData["ProductName"] = productObj.ProductName;
            return View(purchaseObj);
        }

        public IActionResult SavePurchase(Models.PurchaseDetails purchaseObj)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    ViewData["QuantityPurchased"] = purchaseObj.QuantityPurchased;
                    var status = repObj.PurchaseProduct(_mapper.Map<PurchaseDetails>(purchaseObj));
                    if (status)
                    {
                        return View("Sucess");
                    }
                    else
                    {
                        return View("Error");
                    }
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View("PurchaseProduct", purchaseObj);
        }

    }
}
